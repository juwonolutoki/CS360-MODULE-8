package com.example.modulefivebyjuwon;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize EditText fields
        usernameEditText = findViewById(R.id.username);
        passwordEditText = findViewById(R.id.password);
    }

    /**
     * Handles the login button click event.
     */
    public void loginUser(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate user input
        if (username.isEmpty()) {
            usernameEditText.setError("Username cannot be empty");
            usernameEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            passwordEditText.requestFocus();
            return;
        }

        // Mock logic to verify credentials
        if (username.equals("user") && password.equals("password")) {
            // Navigate to the data display activity
            Intent intent = new Intent(LoginActivity.this, DataDisplayActivity.class);
            startActivity(intent);
            finish(); // Close the login activity
        } else {
            Toast.makeText(this, "Invalid credentials", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Handles the create account button click event.
     */
    public void createAccount(View view) {
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        // Validate user input
        if (username.isEmpty()) {
            usernameEditText.setError("Username cannot be empty");
            usernameEditText.requestFocus();
            return;
        }

        if (password.isEmpty()) {
            passwordEditText.setError("Password cannot be empty");
            passwordEditText.requestFocus();
            return;
        }

        // Mock logic for account creation
        // In a real-world scenario, this should save the credentials to a database or use an API
        Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show();

        // Clear the input fields after successful account creation
        usernameEditText.setText("");
        passwordEditText.setText("");
    }
}
